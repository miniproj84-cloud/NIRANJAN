"use client"

import { useState, useEffect, useCallback } from "react"

const STORAGE_KEY = "resume_data"
const RESUMES_LIST_KEY = "resumes_list"

export interface Resume {
  id: string
  name: string
  data: any
  createdAt: string
  updatedAt: string
}

export function useResumeStorage() {
  const [resumes, setResumes] = useState<Resume[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Load resumes from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(RESUMES_LIST_KEY)
      if (stored) {
        setResumes(JSON.parse(stored))
      }
    } catch (error) {
      console.error("Error loading resumes:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Save resume
  const saveResume = useCallback(
    (name: string, data: any): Resume => {
      const id = Date.now().toString()
      const now = new Date().toISOString()
      const resume: Resume = {
        id,
        name,
        data,
        createdAt: now,
        updatedAt: now,
      }

      const updated = [...resumes, resume]
      setResumes(updated)
      localStorage.setItem(RESUMES_LIST_KEY, JSON.stringify(updated))
      return resume
    },
    [resumes],
  )

  // Update resume
  const updateResume = useCallback(
    (id: string, name: string, data: any) => {
      const updated = resumes.map((resume) =>
        resume.id === id ? { ...resume, name, data, updatedAt: new Date().toISOString() } : resume,
      )
      setResumes(updated)
      localStorage.setItem(RESUMES_LIST_KEY, JSON.stringify(updated))
    },
    [resumes],
  )

  // Delete resume
  const deleteResume = useCallback(
    (id: string) => {
      const updated = resumes.filter((resume) => resume.id !== id)
      setResumes(updated)
      localStorage.setItem(RESUMES_LIST_KEY, JSON.stringify(updated))
    },
    [resumes],
  )

  // Get single resume
  const getResume = useCallback(
    (id: string) => {
      return resumes.find((resume) => resume.id === id)
    },
    [resumes],
  )

  return {
    resumes,
    isLoading,
    saveResume,
    updateResume,
    deleteResume,
    getResume,
  }
}
