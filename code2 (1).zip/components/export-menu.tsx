"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Download, Copy, Mail, FileJson } from "lucide-react"

interface ExportMenuProps {
  resumeData: any
}

export default function ExportMenu({ resumeData }: ExportMenuProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleExportPDF = () => {
    // Create a new window for printing
    const printWindow = window.open("", "", "height=600,width=800")
    if (!printWindow) return

    const resumeHTML = generateResumeHTML()
    printWindow.document.write(resumeHTML)
    printWindow.document.close()
    printWindow.focus()

    setTimeout(() => {
      printWindow.print()
      printWindow.close()
    }, 250)
  }

  const handleExportJSON = () => {
    const dataStr = JSON.stringify(resumeData, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `${resumeData.personal.fullName || "resume"}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const handleCopyJSON = () => {
    const dataStr = JSON.stringify(resumeData, null, 2)
    navigator.clipboard.writeText(dataStr).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  const handleShareEmail = () => {
    const subject = `My Resume - ${resumeData.personal.fullName}`
    const body = `Hi,\n\nPlease find my resume attached or below.\n\n${JSON.stringify(resumeData, null, 2)}`
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }

  const generateResumeHTML = () => {
    const { personal, experience, education, skills, certifications } = resumeData

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>${personal.fullName}'s Resume</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; max-width: 8.5in; margin: 0 auto; padding: 20px; }
          h1 { color: #1a3a6b; font-size: 24px; margin-bottom: 5px; }
          h2 { color: #1a3a6b; font-size: 14px; margin-top: 15px; margin-bottom: 8px; border-bottom: 2px solid #1a3a6b; padding-bottom: 3px; }
          h3 { font-size: 12px; margin-bottom: 2px; }
          .header { border-bottom: 2px solid #1a3a6b; padding-bottom: 10px; margin-bottom: 15px; }
          .contact { font-size: 10px; color: #666; }
          .entry { margin-bottom: 10px; font-size: 11px; }
          .position { font-weight: bold; }
          .company { color: #666; }
          .date { color: #999; float: right; }
          .skills { display: flex; flex-wrap: wrap; gap: 5px; }
          .skill-tag { background: #e8f1f8; padding: 2px 6px; border-radius: 3px; font-size: 10px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>${personal.fullName || "Your Name"}</h1>
          <div class="contact">
            ${personal.email ? `${personal.email} • ` : ""}
            ${personal.phone ? `${personal.phone} • ` : ""}
            ${personal.location ? `${personal.location}` : ""}
          </div>
        </div>

        ${
          personal.summary
            ? `
          <div>
            <h2>Professional Summary</h2>
            <p style="margin: 0; font-size: 11px;">${personal.summary}</p>
          </div>
        `
            : ""
        }

        ${
          experience.some((e: any) => e.company)
            ? `
          <div>
            <h2>Professional Experience</h2>
            ${experience
              .map((exp: any) =>
                exp.company
                  ? `
              <div class="entry">
                <div><span class="position">${exp.position}</span> <span class="date">${exp.startDate || ""} - ${exp.endDate || ""}</span></div>
                <div class="company">${exp.company}</div>
                ${exp.description ? `<div>${exp.description}</div>` : ""}
              </div>
            `
                  : "",
              )
              .join("")}
          </div>
        `
            : ""
        }

        ${
          education.some((e: any) => e.school)
            ? `
          <div>
            <h2>Education</h2>
            ${education
              .map((edu: any) =>
                edu.school
                  ? `
              <div class="entry">
                <div><span class="position">${edu.degree}${edu.field ? ` in ${edu.field}` : ""}</span> <span class="date">${edu.graduationDate || ""}</span></div>
                <div class="company">${edu.school}</div>
              </div>
            `
                  : "",
              )
              .join("")}
          </div>
        `
            : ""
        }

        ${
          skills.some((s: string) => s)
            ? `
          <div>
            <h2>Skills</h2>
            <div class="skills">
              ${skills.map((skill: string) => (skill ? `<span class="skill-tag">${skill}</span>` : "")).join("")}
            </div>
          </div>
        `
            : ""
        }

        ${
          certifications.some((c: any) => c.name)
            ? `
          <div>
            <h2>Certifications</h2>
            ${certifications
              .map((cert: any) =>
                cert.name
                  ? `
              <div class="entry">
                <div class="position">${cert.name}</div>
                <div class="company">${cert.issuer}${cert.date ? ` • ${cert.date}` : ""}</div>
              </div>
            `
                  : "",
              )
              .join("")}
          </div>
        `
            : ""
        }
      </body>
      </html>
    `
  }

  return (
    <div className="relative">
      <Button onClick={() => setIsOpen(!isOpen)} className="w-full gap-2">
        <Download className="w-4 h-4" />
        Export
      </Button>

      {isOpen && (
        <div className="absolute top-full right-0 mt-2 w-56 bg-card border border-border rounded-lg shadow-lg z-50">
          <div className="p-3 space-y-2">
            <button
              onClick={handleExportPDF}
              className="w-full flex items-center gap-3 px-4 py-2 hover:bg-muted rounded-lg transition-colors text-left"
            >
              <Download className="w-4 h-4 text-primary" />
              <div>
                <div className="font-medium text-sm">Export as PDF</div>
                <div className="text-xs text-muted-foreground">Print-ready format</div>
              </div>
            </button>

            <button
              onClick={handleExportJSON}
              className="w-full flex items-center gap-3 px-4 py-2 hover:bg-muted rounded-lg transition-colors text-left"
            >
              <FileJson className="w-4 h-4 text-primary" />
              <div>
                <div className="font-medium text-sm">Export as JSON</div>
                <div className="text-xs text-muted-foreground">Backup your resume</div>
              </div>
            </button>

            <button
              onClick={handleCopyJSON}
              className="w-full flex items-center gap-3 px-4 py-2 hover:bg-muted rounded-lg transition-colors text-left"
            >
              <Copy className="w-4 h-4 text-primary" />
              <div>
                <div className="font-medium text-sm">{copied ? "Copied!" : "Copy Data"}</div>
                <div className="text-xs text-muted-foreground">Copy to clipboard</div>
              </div>
            </button>

            <button
              onClick={handleShareEmail}
              className="w-full flex items-center gap-3 px-4 py-2 hover:bg-muted rounded-lg transition-colors text-left"
            >
              <Mail className="w-4 h-4 text-primary" />
              <div>
                <div className="font-medium text-sm">Share via Email</div>
                <div className="text-xs text-muted-foreground">Send as email</div>
              </div>
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
