"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { QrCode, Copy, Download } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface QRGeneratorProps {
  resumeData: any
  resumeName?: string
}

export default function QRGenerator({ resumeData, resumeName = "Resume" }: QRGeneratorProps) {
  const [open, setOpen] = useState(false)
  const [qrImage, setQrImage] = useState<string>("")
  const { toast } = useToast()

  const generateQR = async () => {
    try {
      // Create shareable data object with resume information
      const shareData = {
        name: resumeName,
        data: resumeData,
        timestamp: new Date().toISOString(),
      }

      // Convert to JSON and encode
      const jsonString = JSON.stringify(shareData)
      const encodedData = encodeURIComponent(jsonString)

      // Use QR code API to generate QR code
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodedData}`

      setQrImage(qrUrl)
      toast({
        title: "QR Code Generated",
        description: "QR code is ready to share",
      })
    } catch (error) {
      console.error("Error generating QR code:", error)
      toast({
        title: "Error",
        description: "Failed to generate QR code",
        variant: "destructive",
      })
    }
  }

  const downloadQR = async () => {
    try {
      const response = await fetch(qrImage)
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = `${resumeName}-qr-code.png`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
      toast({
        title: "Downloaded",
        description: "QR code downloaded successfully",
      })
    } catch (error) {
      console.error("Error downloading QR code:", error)
      toast({
        title: "Error",
        description: "Failed to download QR code",
        variant: "destructive",
      })
    }
  }

  const copyToClipboard = async () => {
    try {
      // Create shareable link with resume data
      const shareData = {
        name: resumeName,
        data: resumeData,
      }
      const jsonString = JSON.stringify(shareData)
      await navigator.clipboard.writeText(jsonString)
      toast({
        title: "Copied",
        description: "Resume data copied to clipboard",
      })
    } catch (error) {
      console.error("Error copying to clipboard:", error)
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  return (
    <>
      <Button
        onClick={() => {
          generateQR()
          setOpen(true)
        }}
        variant="outline"
        className="bg-transparent"
      >
        <QrCode className="w-4 h-4 mr-2" />
        QR Code
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Share Resume via QR Code</DialogTitle>
            <DialogDescription>Generate a QR code to easily share your resume with others</DialogDescription>
          </DialogHeader>

          <div className="flex flex-col items-center gap-4">
            {qrImage && (
              <div className="p-4 bg-white rounded-lg border border-border">
                <img src={qrImage || "/placeholder.svg"} alt="Resume QR Code" className="w-64 h-64" />
              </div>
            )}

            <div className="w-full space-y-2">
              <Button onClick={downloadQR} className="w-full" disabled={!qrImage}>
                <Download className="w-4 h-4 mr-2" />
                Download QR Code
              </Button>
              <Button onClick={copyToClipboard} variant="outline" className="w-full bg-transparent">
                <Copy className="w-4 h-4 mr-2" />
                Copy Resume Data
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
