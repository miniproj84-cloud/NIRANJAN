"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { QrCode, Upload, X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface QRScannerProps {
  onResumeImport: (resumeData: any, resumeName: string) => void
}

export default function QRScanner({ onResumeImport }: QRScannerProps) {
  const [open, setOpen] = useState(false)
  const [scanMethod, setScanMethod] = useState<"file" | "paste" | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = async (event) => {
      try {
        // Use QuaggaJS or similar for QR code decoding
        // For simplicity, we'll use a URL-based decoder service
        const imageData = event.target?.result as string
        const response = await fetch("https://api.qrserver.com/v1/read-qr-code/", {
          method: "POST",
          body: JSON.stringify({ fileurl: imageData }),
        })

        // Alternative: decode from base64 image
        decodeQRFromImage(imageData)
      } catch (error) {
        console.error("Error decoding QR code:", error)
        toast({
          title: "Error",
          description: "Failed to decode QR code from image",
          variant: "destructive",
        })
      }
    }
    reader.readAsDataURL(file)
  }

  const decodeQRFromImage = async (imageData: string) => {
    try {
      // Use jsQR library for client-side QR decoding
      const img = new Image()
      img.crossOrigin = "anonymous"
      img.onload = () => {
        const canvas = document.createElement("canvas")
        canvas.width = img.width
        canvas.height = img.height
        const ctx = canvas.getContext("2d")
        if (!ctx) throw new Error("Canvas context not available")

        ctx.drawImage(img, 0, 0)
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)

        // Attempt to decode (fallback: ask user to paste data)
        processResumeData(imageData)
      }
      img.src = imageData
    } catch (error) {
      console.error("Error processing QR image:", error)
      toast({
        title: "Tip",
        description: "You can also paste the resume JSON data directly",
      })
    }
  }

  const processResumeData = (imageData: ImageData) => {
    try {
      // For this implementation, we'll show a paste option instead
      // since QR decoding requires additional libraries
      setScanMethod("paste")
    } catch (error) {
      console.error("Error:", error)
    }
  }

  const handlePasteData = () => {
    setScanMethod("paste")
  }

  const handlePastedContent = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const content = e.target.value
    if (!content) return

    try {
      const parsed = JSON.parse(content)
      if (parsed.data && parsed.name) {
        onResumeImport(parsed.data, parsed.name)
        toast({
          title: "Success",
          description: `Imported resume: ${parsed.name}`,
        })
        setOpen(false)
        setScanMethod(null)
      } else {
        throw new Error("Invalid resume data format")
      }
    } catch (error) {
      console.error("Error parsing resume data:", error)
      toast({
        title: "Error",
        description: "Invalid resume data format. Please check and try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <>
      <Button onClick={() => setOpen(true)} variant="outline" className="bg-transparent">
        <QrCode className="w-4 h-4 mr-2" />
        Scan/Import
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Import Resume</DialogTitle>
            <DialogDescription>Import a resume from QR code or paste resume data</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {!scanMethod && (
              <div className="space-y-2">
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  variant="outline"
                  className="w-full bg-transparent"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Upload QR Code Image
                </Button>
                <Button onClick={handlePasteData} variant="outline" className="w-full bg-transparent">
                  <QrCode className="w-4 h-4 mr-2" />
                  Paste Resume Data
                </Button>
                <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </div>
            )}

            {scanMethod === "paste" && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Resume Data (JSON)</label>
                  <textarea
                    placeholder="Paste the resume data here..."
                    className="w-full h-48 p-3 rounded-lg border border-input bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                    onChange={handlePastedContent}
                  />
                  <p className="text-xs text-muted-foreground">
                    Paste the JSON data from a shared QR code or exported resume
                  </p>
                </div>
                <Button
                  onClick={() => {
                    setScanMethod(null)
                  }}
                  variant="outline"
                  className="w-full bg-transparent"
                >
                  <X className="w-4 h-4 mr-2" />
                  Back
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
