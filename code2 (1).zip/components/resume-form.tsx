"use client"

import type React from "react"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Plus, X, Upload } from "lucide-react"
import { useState } from "react"

interface ResumeFormProps {
  resumeData: any
  onUpdate: (data: any) => void
}

export default function ResumeForm({ resumeData, onUpdate }: ResumeFormProps) {
  const [activeSection, setActiveSection] = useState<string>("personal")

  const updatePersonal = (field: string, value: string) => {
    onUpdate({
      ...resumeData,
      personal: { ...resumeData.personal, [field]: value },
    })
  }

  const handleProfilePictureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const imageData = event.target?.result as string
        updatePersonal("profilePicture", imageData)
      }
      reader.readAsDataURL(file)
    }
  }

  const updateExperience = (index: number, field: string, value: string) => {
    const updated = [...resumeData.experience]
    updated[index] = { ...updated[index], [field]: value }
    onUpdate({ ...resumeData, experience: updated })
  }

  const addExperience = () => {
    onUpdate({
      ...resumeData,
      experience: [
        ...resumeData.experience,
        { company: "", position: "", startDate: "", endDate: "", description: "" },
      ],
    })
  }

  const removeExperience = (index: number) => {
    const updated = resumeData.experience.filter((_: any, i: number) => i !== index)
    onUpdate({ ...resumeData, experience: updated })
  }

  const updateEducation = (index: number, field: string, value: string) => {
    const updated = [...resumeData.education]
    updated[index] = { ...updated[index], [field]: value }
    onUpdate({ ...resumeData, education: updated })
  }

  const addEducation = () => {
    onUpdate({
      ...resumeData,
      education: [...resumeData.education, { school: "", degree: "", field: "", graduationDate: "", details: "" }],
    })
  }

  const removeEducation = (index: number) => {
    const updated = resumeData.education.filter((_: any, i: number) => i !== index)
    onUpdate({ ...resumeData, education: updated })
  }

  const updateSkills = (index: number, value: string) => {
    const updated = [...resumeData.skills]
    updated[index] = value
    onUpdate({ ...resumeData, skills: updated })
  }

  const addSkill = () => {
    onUpdate({ ...resumeData, skills: [...resumeData.skills, ""] })
  }

  const removeSkill = (index: number) => {
    const updated = resumeData.skills.filter((_: string, i: number) => i !== index)
    onUpdate({ ...resumeData, skills: updated })
  }

  const sections = [
    { id: "personal", label: "Personal Info" },
    { id: "experience", label: "Experience" },
    { id: "education", label: "Education" },
    { id: "skills", label: "Skills" },
    { id: "certifications", label: "Certifications" },
  ]

  return (
    <div className="space-y-6">
      {/* Section Navigation */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {sections.map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            className={`px-3 py-2 rounded-lg font-medium text-sm transition-colors ${
              activeSection === section.id
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:text-foreground"
            }`}
          >
            {section.label}
          </button>
        ))}
      </div>

      {/* Personal Info Section */}
      {activeSection === "personal" && (
        <Card className="p-6 space-y-4">
          <h3 className="text-lg font-bold text-foreground">Personal Information</h3>

          {/* Profile Picture Upload Section */}
          <div className="flex flex-col items-center gap-4 pb-4 border-b">
            <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center overflow-hidden border-2 border-primary">
              {resumeData.personal.profilePicture ? (
                <img
                  src={resumeData.personal.profilePicture || "/placeholder.svg"}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-center">
                  <Upload className="w-8 h-8 text-muted-foreground mx-auto" />
                  <p className="text-xs text-muted-foreground mt-1">Upload</p>
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <input
                type="file"
                accept="image/*"
                onChange={handleProfilePictureUpload}
                className="hidden"
                id="profile-upload"
              />
              <label htmlFor="profile-upload">
                <Button asChild variant="outline">
                  <span>Change Picture</span>
                </Button>
              </label>
              {resumeData.personal.profilePicture && (
                <Button
                  variant="outline"
                  className="text-destructive hover:text-destructive bg-transparent"
                  onClick={() => updatePersonal("profilePicture", "")}
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Full Name</label>
              <Input
                placeholder="John Doe"
                value={resumeData.personal.fullName}
                onChange={(e) => updatePersonal("fullName", e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Email</label>
              <Input
                type="email"
                placeholder="john@example.com"
                value={resumeData.personal.email}
                onChange={(e) => updatePersonal("email", e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Phone</label>
              <Input
                type="tel"
                placeholder="+1 (555) 000-0000"
                value={resumeData.personal.phone}
                onChange={(e) => updatePersonal("phone", e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Location</label>
              <Input
                placeholder="New York, NY"
                value={resumeData.personal.location}
                onChange={(e) => updatePersonal("location", e.target.value)}
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-foreground mb-2">Website/Portfolio</label>
              <Input
                placeholder="https://yourwebsite.com"
                value={resumeData.personal.website}
                onChange={(e) => updatePersonal("website", e.target.value)}
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-foreground mb-2">Professional Summary</label>
              <Textarea
                placeholder="Brief summary of your professional background..."
                rows={4}
                value={resumeData.personal.summary}
                onChange={(e) => updatePersonal("summary", e.target.value)}
              />
            </div>
          </div>
        </Card>
      )}

      {/* Experience Section */}
      {activeSection === "experience" && (
        <div className="space-y-4">
          {resumeData.experience.map((exp: any, idx: number) => (
            <Card key={idx} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-bold text-foreground">Experience {idx + 1}</h3>
                {resumeData.experience.length > 1 && (
                  <button onClick={() => removeExperience(idx)} className="text-destructive hover:text-destructive/80">
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Company</label>
                  <Input
                    placeholder="Company Name"
                    value={exp.company}
                    onChange={(e) => updateExperience(idx, "company", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Position</label>
                  <Input
                    placeholder="Job Title"
                    value={exp.position}
                    onChange={(e) => updateExperience(idx, "position", e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Start Date</label>
                    <Input
                      type="month"
                      value={exp.startDate}
                      onChange={(e) => updateExperience(idx, "startDate", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">End Date</label>
                    <Input
                      type="month"
                      value={exp.endDate}
                      onChange={(e) => updateExperience(idx, "endDate", e.target.value)}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Description</label>
                  <Textarea
                    placeholder="Describe your responsibilities and achievements..."
                    rows={3}
                    value={exp.description}
                    onChange={(e) => updateExperience(idx, "description", e.target.value)}
                  />
                </div>
              </div>
            </Card>
          ))}
          <Button onClick={addExperience} variant="outline" className="w-full bg-transparent">
            <Plus className="w-4 h-4 mr-2" />
            Add Experience
          </Button>
        </div>
      )}

      {/* Education Section */}
      {activeSection === "education" && (
        <div className="space-y-4">
          {resumeData.education.map((edu: any, idx: number) => (
            <Card key={idx} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-bold text-foreground">Education {idx + 1}</h3>
                {resumeData.education.length > 1 && (
                  <button onClick={() => removeEducation(idx)} className="text-destructive hover:text-destructive/80">
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">School/University</label>
                  <Input
                    placeholder="University Name"
                    value={edu.school}
                    onChange={(e) => updateEducation(idx, "school", e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Degree</label>
                    <Input
                      placeholder="Bachelor's"
                      value={edu.degree}
                      onChange={(e) => updateEducation(idx, "degree", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Field of Study</label>
                    <Input
                      placeholder="Computer Science"
                      value={edu.field}
                      onChange={(e) => updateEducation(idx, "field", e.target.value)}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Graduation Date</label>
                  <Input
                    type="month"
                    value={edu.graduationDate}
                    onChange={(e) => updateEducation(idx, "graduationDate", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Details</label>
                  <Textarea
                    placeholder="GPA, honors, activities, etc..."
                    rows={3}
                    value={edu.details}
                    onChange={(e) => updateEducation(idx, "details", e.target.value)}
                  />
                </div>
              </div>
            </Card>
          ))}
          <Button onClick={addEducation} variant="outline" className="w-full bg-transparent">
            <Plus className="w-4 h-4 mr-2" />
            Add Education
          </Button>
        </div>
      )}

      {/* Skills Section */}
      {activeSection === "skills" && (
        <div className="space-y-4">
          <Card className="p-6">
            <h3 className="font-bold text-foreground mb-4">Skills</h3>
            <div className="space-y-3">
              {resumeData.skills.map((skill: string, idx: number) => (
                <div key={idx} className="flex gap-2">
                  <Input
                    placeholder="e.g., JavaScript, React, Python"
                    value={skill}
                    onChange={(e) => updateSkills(idx, e.target.value)}
                  />
                  {resumeData.skills.length > 1 && (
                    <button onClick={() => removeSkill(idx)} className="text-destructive hover:text-destructive/80">
                      <X className="w-5 h-5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
            <Button onClick={addSkill} variant="outline" className="w-full mt-4 bg-transparent">
              <Plus className="w-4 h-4 mr-2" />
              Add Skill
            </Button>
          </Card>
        </div>
      )}

      {/* Certifications Section */}
      {activeSection === "certifications" && (
        <div className="space-y-4">
          {resumeData.certifications.map((cert: any, idx: number) => (
            <Card key={idx} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-bold text-foreground">Certification {idx + 1}</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Certification Name</label>
                  <Input
                    placeholder="AWS Certified Solutions Architect"
                    value={cert.name}
                    onChange={(e) =>
                      onUpdate({
                        ...resumeData,
                        certifications: resumeData.certifications.map((c: any, i: number) =>
                          i === idx ? { ...c, name: e.target.value } : c,
                        ),
                      })
                    }
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Issuer</label>
                    <Input
                      placeholder="Amazon Web Services"
                      value={cert.issuer}
                      onChange={(e) =>
                        onUpdate({
                          ...resumeData,
                          certifications: resumeData.certifications.map((c: any, i: number) =>
                            i === idx ? { ...c, issuer: e.target.value } : c,
                          ),
                        })
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Date</label>
                    <Input
                      type="month"
                      value={cert.date}
                      onChange={(e) =>
                        onUpdate({
                          ...resumeData,
                          certifications: resumeData.certifications.map((c: any, i: number) =>
                            i === idx ? { ...c, date: e.target.value } : c,
                          ),
                        })
                      }
                    />
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
