"use client"

import { Card } from "@/components/ui/card"
import { Mail, Phone, MapPin, Globe } from "lucide-react"

interface ResumePreviewProps {
  resumeData: any
  templateId?: string
}

export default function ResumePreview({ resumeData, templateId = "modern" }: ResumePreviewProps) {
  const { personal, experience, education, skills, certifications } = resumeData

  const templateStyles = {
    modern: {
      headerBorder: "border-b-2 border-primary",
      nameColor: "text-primary",
      sectionTitleColor: "text-primary",
      sectionTitleSize: "text-lg",
      accentColor: "bg-secondary",
      badgeColor: "bg-secondary text-gray-900",
      dividerColor: "border-primary/30",
    },
    professional: {
      headerBorder: "border-b-4 border-blue-900",
      nameColor: "text-blue-900",
      sectionTitleColor: "text-blue-900",
      sectionTitleSize: "text-base",
      accentColor: "bg-blue-50",
      badgeColor: "bg-blue-100 text-blue-900",
      dividerColor: "border-blue-200",
    },
    creative: {
      headerBorder: "border-l-8 border-pink-500",
      nameColor: "text-pink-600",
      sectionTitleColor: "text-pink-500",
      sectionTitleSize: "text-lg font-black",
      accentColor: "bg-pink-50",
      badgeColor: "bg-pink-200 text-pink-900",
      dividerColor: "border-pink-200",
    },
    minimal: {
      headerBorder: "border-t-2 border-gray-400",
      nameColor: "text-gray-800",
      sectionTitleColor: "text-gray-700",
      sectionTitleSize: "text-sm font-semibold uppercase tracking-widest",
      accentColor: "bg-gray-100",
      badgeColor: "bg-gray-200 text-gray-800",
      dividerColor: "border-gray-300",
    },
    executive: {
      headerBorder: "border-b-4 border-slate-800",
      nameColor: "text-slate-900",
      sectionTitleColor: "text-slate-800",
      sectionTitleSize: "text-base font-bold",
      accentColor: "bg-slate-100",
      badgeColor: "bg-slate-700 text-white",
      dividerColor: "border-slate-300",
    },
    technical: {
      headerBorder: "border-b-2 border-cyan-500",
      nameColor: "text-cyan-600",
      sectionTitleColor: "text-cyan-600",
      sectionTitleSize: "text-lg font-bold",
      accentColor: "bg-cyan-50",
      badgeColor: "bg-cyan-600 text-white",
      dividerColor: "border-cyan-200",
    },
    academic: {
      headerBorder: "border-b-4 border-purple-700",
      nameColor: "text-purple-800",
      sectionTitleColor: "text-purple-700",
      sectionTitleSize: "text-base font-bold",
      accentColor: "bg-purple-50",
      badgeColor: "bg-purple-200 text-purple-900",
      dividerColor: "border-purple-200",
    },
    chronological: {
      headerBorder: "border-b-2 border-green-700",
      nameColor: "text-green-800",
      sectionTitleColor: "text-green-700",
      sectionTitleSize: "text-base font-bold",
      accentColor: "bg-green-50",
      badgeColor: "bg-green-700 text-white",
      dividerColor: "border-green-200",
    },
  }

  const style = templateStyles[templateId as keyof typeof templateStyles] || templateStyles.modern

  return (
    <Card className="p-8 bg-white text-black shadow-lg print:shadow-none">
      {/* Header */}
      <div className={`${style.headerBorder} pb-6 mb-6`}>
        <div className="flex gap-6 items-start mb-4">
          {personal.profilePicture && (
            <div className={`w-24 h-24 rounded-full flex-shrink-0 overflow-hidden border-2 ${style.dividerColor}`}>
              <img
                src={personal.profilePicture || "/placeholder.svg"}
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
          )}
          <div className="flex-1">
            <h1
              className={`${style.nameColor} mb-2 font-bold ${
                templateId === "minimal"
                  ? "text-2xl"
                  : templateId === "professional"
                    ? "text-3xl"
                    : templateId === "creative"
                      ? "text-4xl"
                      : "text-4xl"
              }`}
            >
              {personal.fullName || "Your Name"}
            </h1>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              {personal.email && (
                <div className="flex items-center gap-1">
                  <Mail className="w-4 h-4" />
                  {personal.email}
                </div>
              )}
              {personal.phone && (
                <div className="flex items-center gap-1">
                  <Phone className="w-4 h-4" />
                  {personal.phone}
                </div>
              )}
              {personal.location && (
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {personal.location}
                </div>
              )}
              {personal.website && (
                <div className="flex items-center gap-1">
                  <Globe className="w-4 h-4" />
                  {personal.website}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Professional Summary */}
      {personal.summary && (
        <div className="mb-6">
          <h2 className={`${style.sectionTitleColor} ${style.sectionTitleSize} font-bold mb-2`}>
            Professional Summary
          </h2>
          <p className="text-gray-700 text-sm leading-relaxed">{personal.summary}</p>
        </div>
      )}

      {/* Experience */}
      {experience.some((exp: any) => exp.company) && (
        <div className="mb-6">
          <h2 className={`${style.sectionTitleColor} ${style.sectionTitleSize} font-bold mb-3`}>
            Professional Experience
          </h2>
          <div className="space-y-4">
            {experience.map((exp: any, idx: number) =>
              exp.company ? (
                <div
                  key={idx}
                  className={`pb-4 ${idx < experience.length - 1 ? `border-b ${style.dividerColor}` : ""}`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-gray-900">{exp.position}</h3>
                      <p className={`text-sm ${style.sectionTitleColor}`}>{exp.company}</p>
                    </div>
                    <div className="text-sm text-gray-600 text-right">
                      {exp.startDate && exp.startDate.slice(0, 7)}
                      {exp.endDate && ` - ${exp.endDate.slice(0, 7)}`}
                    </div>
                  </div>
                  {exp.description && <p className="text-sm text-gray-700 mt-2 leading-relaxed">{exp.description}</p>}
                </div>
              ) : null,
            )}
          </div>
        </div>
      )}

      {/* Education */}
      {education.some((edu: any) => edu.school) && (
        <div className="mb-6">
          <h2 className={`${style.sectionTitleColor} ${style.sectionTitleSize} font-bold mb-3`}>Education</h2>
          <div className="space-y-4">
            {education.map((edu: any, idx: number) =>
              edu.school ? (
                <div key={idx} className={`pb-4 ${idx < education.length - 1 ? `border-b ${style.dividerColor}` : ""}`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-gray-900">
                        {edu.degree} {edu.field && `in ${edu.field}`}
                      </h3>
                      <p className={`text-sm ${style.sectionTitleColor}`}>{edu.school}</p>
                    </div>
                    {edu.graduationDate && (
                      <div className="text-sm text-gray-600">{edu.graduationDate.slice(0, 7)}</div>
                    )}
                  </div>
                  {edu.details && <p className="text-sm text-gray-700 mt-2 leading-relaxed">{edu.details}</p>}
                </div>
              ) : null,
            )}
          </div>
        </div>
      )}

      {/* Skills */}
      {skills.some((skill: string) => skill) && (
        <div className="mb-6">
          <h2 className={`${style.sectionTitleColor} ${style.sectionTitleSize} font-bold mb-3`}>Skills</h2>
          <div className={`flex flex-wrap gap-2 ${templateId === "minimal" ? "gap-1" : ""}`}>
            {skills.map((skill: string, idx: number) =>
              skill ? (
                <span
                  key={idx}
                  className={`${style.badgeColor} px-3 py-1 rounded ${templateId === "minimal" ? "rounded-sm text-xs" : "text-sm"} font-medium`}
                >
                  {skill}
                </span>
              ) : null,
            )}
          </div>
        </div>
      )}

      {/* Certifications */}
      {certifications.some((cert: any) => cert.name) && (
        <div>
          <h2 className={`${style.sectionTitleColor} ${style.sectionTitleSize} font-bold mb-3`}>Certifications</h2>
          <div className="space-y-2">
            {certifications.map((cert: any, idx: number) =>
              cert.name ? (
                <div key={idx} className="text-sm">
                  <div className="font-bold text-gray-900">{cert.name}</div>
                  <div className="text-gray-600">
                    {cert.issuer}
                    {cert.date && ` • ${cert.date.slice(0, 7)}`}
                  </div>
                </div>
              ) : null,
            )}
          </div>
        </div>
      )}
    </Card>
  )
}
