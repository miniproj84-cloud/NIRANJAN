"use client"

import { useResumeStorage } from "@/hooks/use-resume-storage"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { FileText, Plus, Trash2, Edit2 } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export default function ResumeDashboard() {
  const { resumes, isLoading, deleteResume } = useResumeStorage()
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-muted-foreground">Loading resumes...</div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-foreground">My Resumes</h2>
        <Link href="/builder">
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            New Resume
          </Button>
        </Link>
      </div>

      {resumes.length === 0 ? (
        <Card className="p-12 text-center">
          <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No resumes yet</h3>
          <p className="text-muted-foreground mb-6">Create your first resume to get started</p>
          <Link href="/builder">
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Resume
            </Button>
          </Link>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resumes.map((resume) => (
            <Card key={resume.id} className="p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <FileText className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">{resume.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      Updated {new Date(resume.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Link href={`/builder?id=${resume.id}`}>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Edit2 className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                </Link>

                {deleteConfirm === resume.id ? (
                  <div className="space-y-2">
                    <p className="text-sm text-foreground font-medium">Delete this resume?</p>
                    <div className="flex gap-2">
                      <Button
                        variant="destructive"
                        size="sm"
                        className="flex-1"
                        onClick={() => {
                          deleteResume(resume.id)
                          setDeleteConfirm(null)
                        }}
                      >
                        Delete
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 bg-transparent"
                        onClick={() => setDeleteConfirm(null)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Button
                    variant="ghost"
                    className="w-full text-destructive hover:text-destructive hover:bg-destructive/10"
                    onClick={() => setDeleteConfirm(resume.id)}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
