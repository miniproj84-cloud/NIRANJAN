"use client"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import ResumeForm from "@/components/resume-form"
import ResumePreview from "@/components/resume-preview"
import ExportMenu from "@/components/export-menu"
import QRGenerator from "@/components/qr-generator"
import QRScanner from "@/components/qr-scanner"
import { useResumeStorage } from "@/hooks/use-resume-storage"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Eye, Edit, Save } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function BuilderPage() {
  const [activeTab, setActiveTab] = useState<"edit" | "preview">("edit")
  const [resumeName, setResumeName] = useState("My Resume")
  const [isEditing, setIsEditing] = useState(false)
  const [resumeId, setResumeId] = useState<string | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [templateId, setTemplateId] = useState("modern") // Added template selection
  const searchParams = useSearchParams()
  const router = useRouter()
  const { saveResume, updateResume, getResume } = useResumeStorage()
  const { toast } = useToast()

  const [resumeData, setResumeData] = useState({
    personal: {
      fullName: "",
      email: "",
      phone: "",
      location: "",
      website: "",
      summary: "",
      profilePicture: "",
    },
    experience: [{ company: "", position: "", startDate: "", endDate: "", description: "" }],
    education: [{ school: "", degree: "", field: "", graduationDate: "", details: "" }],
    skills: [""],
    certifications: [{ name: "", issuer: "", date: "" }],
  })

  useEffect(() => {
    const id = searchParams.get("id")
    if (id) {
      const existing = getResume(id)
      if (existing) {
        setResumeId(id)
        setResumeName(existing.name)
        setResumeData(existing.data)
      }
    }
  }, [searchParams, getResume])

  const updateResumeData = (newData: typeof resumeData) => {
    setResumeData(newData)
  }

  const handleSaveResume = async () => {
    if (!resumeName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a resume name",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)
    try {
      if (resumeId) {
        updateResume(resumeId, resumeName, resumeData)
        toast({
          title: "Success",
          description: "Resume updated successfully",
        })
      } else {
        const saved = saveResume(resumeName, resumeData)
        setResumeId(saved.id)
        toast({
          title: "Success",
          description: "Resume saved successfully",
        })
      }
    } catch (error) {
      console.error("Error saving resume:", error)
      toast({
        title: "Error",
        description: "Failed to save resume",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleImportedResume = (importedData: any, importedName: string) => {
    setResumeData(importedData)
    setResumeName(importedName)
    setResumeId(null)
    toast({
      title: "Success",
      description: `Imported resume: ${importedName}`,
    })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                {isEditing ? (
                  <Input
                    value={resumeName}
                    onChange={(e) => setResumeName(e.target.value)}
                    placeholder="Resume name"
                    className="max-w-xs"
                    autoFocus
                    onBlur={() => setIsEditing(false)}
                  />
                ) : (
                  <h1
                    onClick={() => setIsEditing(true)}
                    className="text-3xl font-bold text-foreground cursor-pointer hover:text-primary transition-colors"
                  >
                    {resumeName}
                  </h1>
                )}
              </div>
              <p className="text-muted-foreground">Create your professional resume</p>
            </div>
            <div className="flex gap-2 flex-wrap justify-end items-start">
              <QRGenerator resumeData={resumeData} resumeName={resumeName} />
              <QRScanner onResumeImport={handleImportedResume} />
              <Button onClick={handleSaveResume} disabled={isSaving}>
                <Save className="w-4 h-4 mr-2" />
                {isSaving ? "Saving..." : "Save"}
              </Button>
              <div className="w-32">
                <ExportMenu resumeData={resumeData} />
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab("edit")}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === "edit"
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >
              <Edit className="w-4 h-4 inline mr-2" />
              Edit
            </button>
            <button
              onClick={() => setActiveTab("preview")}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === "preview"
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >
              <Eye className="w-4 h-4 inline mr-2" />
              Preview
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Edit Section */}
          <div className={activeTab === "edit" ? "block" : "hidden lg:block"}>
            <div className="space-y-6">
              <div className="bg-card rounded-lg p-6 border border-border">
                <h3 className="text-sm font-bold text-foreground mb-3">Template Style</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    "modern",
                    "professional",
                    "creative",
                    "minimal",
                    "executive",
                    "technical",
                    "academic",
                    "chronological",
                  ].map((template) => (
                    <button
                      key={template}
                      onClick={() => setTemplateId(template)}
                      className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                        templateId === template
                          ? "bg-primary text-primary-foreground ring-2 ring-primary"
                          : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      {template.charAt(0).toUpperCase() + template.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
              <ResumeForm resumeData={resumeData} onUpdate={updateResumeData} />
            </div>
          </div>

          {/* Preview Section */}
          <div className={activeTab === "preview" ? "block" : "hidden lg:block"}>
            <div className="sticky top-8">
              <ResumePreview resumeData={resumeData} templateId={templateId} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
