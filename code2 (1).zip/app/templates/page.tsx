"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Check } from "lucide-react"
import Link from "next/link"

export default function TemplatesPage() {
  const templates = [
    {
      id: "modern",
      name: "Modern",
      description: "Clean and contemporary design",
      color: "#6366f1",
      preview: "Modern resume template",
    },
    {
      id: "professional",
      name: "Professional",
      description: "Classic corporate style",
      color: "#1a3a6b",
      preview: "Professional resume template",
    },
    {
      id: "creative",
      name: "Creative",
      description: "Bold and artistic layout",
      color: "#ec4899",
      preview: "Creative resume template",
    },
    {
      id: "minimal",
      name: "Minimal",
      description: "Elegant and simple design",
      color: "#666666",
      preview: "Minimal resume template",
    },
    {
      id: "executive",
      name: "Executive",
      description: "Leadership-focused premium style",
      color: "#1e293b",
      preview: "Executive resume template",
    },
    {
      id: "technical",
      name: "Technical",
      description: "Optimized for tech roles and skills",
      color: "#0891b2",
      preview: "Technical resume template",
    },
    {
      id: "academic",
      name: "Academic",
      description: "Research and education focused",
      color: "#7c3aed",
      preview: "Academic resume template",
    },
    {
      id: "chronological",
      name: "Chronological",
      description: "Traditional experience-first format",
      color: "#065f46",
      preview: "Chronological resume template",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-foreground">Resume Templates</h1>
          <p className="text-muted-foreground">Choose from professionally designed templates</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {templates.map((template) => (
            <Card key={template.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-32 relative" style={{ backgroundColor: template.color }}>
                <div className="absolute inset-0 flex items-center justify-center text-white/70">
                  {template.preview}
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg text-foreground mb-1">{template.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{template.description}</p>
                <Link href="/builder">
                  <Button className="w-full">
                    <Check className="w-4 h-4 mr-2" />
                    Use Template
                  </Button>
                </Link>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
