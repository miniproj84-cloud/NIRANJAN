"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { FileText, Download, Sparkles, CheckCircle2 } from 'lucide-react'

export default function HomePage() {
  const features = [
    {
      icon: FileText,
      title: "Professional Templates",
      description: "Choose from expertly designed templates that employers love",
    },
    {
      icon: Download,
      title: "Instant Export",
      description: "Download your resume as PDF or share with one click",
    },
    {
      icon: Sparkles,
      title: "AI-Powered Tips",
      description: "Get real-time suggestions to optimize your resume",
    },
  ]

  const benefits = [
    "ATS-optimized for all applicant tracking systems",
    "Save unlimited drafts and resumes",
    "Real-time preview while editing",
    "Mobile-friendly builder",
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/10">
      {/* Navigation */}
      <nav className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-lg flex items-center justify-center shadow-md">
              <span className="text-primary-foreground font-bold text-sm">NVT</span>
            </div>
            <span className="font-bold text-xl text-foreground">NVT STUDENT RESUME BUILDER</span>
          </div>
          <div className="flex gap-4">
            <Link href="/login">
              <Button variant="ghost">Sign In</Button>
            </Link>
            <Link href="/signup">
              <Button>Get Started</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl sm:text-6xl font-bold text-foreground leading-tight mb-6 text-balance">
              Your Perfect Resume in Minutes
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Create a professional resume that stands out. Our AI-powered builder includes stunning templates and instant export to PDF. Built for students, loved by employers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/builder">
                <Button size="lg" className="w-full sm:w-auto">
                  Start Building Free
                </Button>
              </Link>
              <Link href="/templates">
                <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent">
                  View Templates
                </Button>
              </Link>
            </div>
          </div>
          <div className="bg-card border border-border rounded-lg p-8 shadow-lg">
            <div className="space-y-4">
              <div className="h-64 bg-muted rounded animate-pulse" />
              <div className="space-y-2">
                <div className="h-4 bg-muted rounded w-3/4 animate-pulse" />
                <div className="h-4 bg-muted rounded w-1/2 animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-card border-y border-border py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4 text-balance">Everything You Need to Succeed</h2>
            <p className="text-lg text-muted-foreground">
              Powerful features designed specifically for student job seekers
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, idx) => {
              const Icon = feature.icon
              return (
                <div
                  key={idx}
                  className="bg-background border border-border rounded-lg p-6 hover:shadow-md transition-shadow"
                >
                  <Icon className="w-8 h-8 text-primary mb-4" />
                  <h3 className="font-bold text-lg text-foreground mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="bg-card border border-border rounded-lg p-8 shadow-lg">
            <div className="space-y-4">
              <div className="h-64 bg-muted rounded animate-pulse" />
              <div className="space-y-2">
                <div className="h-4 bg-muted rounded w-3/4 animate-pulse" />
                <div className="h-4 bg-muted rounded w-1/2 animate-pulse" />
              </div>
            </div>
          </div>
          <div>
            <h2 className="text-4xl font-bold text-foreground mb-8 text-balance">
              Why Choose NVT STUDENT RESUME BUILDER?
            </h2>
            <div className="space-y-4">
              {benefits.map((benefit, idx) => (
                <div key={idx} className="flex gap-3 items-start">
                  <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-lg text-foreground">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary text-primary-foreground py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold mb-4 text-balance">Ready to land your dream job?</h2>
          <p className="text-lg mb-8 opacity-90">
            Join hundreds of students who've created amazing resumes with NVT STUDENT RESUME BUILDER
          </p>
          <Link href="/builder">
            <Button size="lg" variant="secondary" className="font-semibold">
              Create Your Resume Now
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-lg flex items-center justify-center shadow-md">
                  <span className="text-primary-foreground font-bold text-sm">NVT</span>
                </div>
                <span className="font-bold text-foreground">NVT STUDENT RESUME BUILDER</span>
              </div>
              <p className="text-sm text-muted-foreground">Professional resumes for the next generation</p>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Product</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/builder" className="hover:text-foreground">
                    Resume Builder
                  </Link>
                </li>
                <li>
                  <Link href="/templates" className="hover:text-foreground">
                    Templates
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Company</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground">
                    About
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Legal</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground">
                    Privacy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground">
                    Terms
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground">
                    Cookies
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2025 NVT STUDENT RESUME BUILDER. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
